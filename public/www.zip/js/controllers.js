angular.module('app.controllers', [])

.controller('loginCtrl', function($scope) {

})

.controller('signupCtrl', function($scope) {

})

.controller('homeCtrl', function($scope) {

})

.controller('newMusiqCtrl', function($scope) {

})

.controller('myLikesCtrl', function($scope) {

})

.controller('popularMusiqCtrl', function($scope) {

})

.controller('artistNameSearchCtrl', function($scope) {

})

.controller('songTitleSearchCtrl', function($scope) {

})

.controller('musiqGenreSearchCtrl', function($scope) {

})

.controller('feedbackCtrl', function($scope) {

})

.controller('aboutCtrl', function($scope) {

})

.controller('artistHomeCtrl', function($scope) {

})

.controller('artistBiographyCtrl', function($scope) {

});
